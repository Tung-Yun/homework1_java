package homework1;

public class sample4 
{
	public static void main(String[] args)
	{
		System.out.println("��ܥX�ϱ׽u:\\");
		System.out.println("��ܥX��޸�\'");
	}
}

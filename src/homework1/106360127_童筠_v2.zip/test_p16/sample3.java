package homework1;

public class sample3 
{
	public static void main(String[] args)
	{
		System.out.println("A");
		System.out.println("�w��ϥ�Java�a!");
		System.out.println("123");
	}
}
